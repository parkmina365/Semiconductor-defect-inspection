
1104_mold_test_1 - v1 1104_mold_2
==============================

This dataset was exported via roboflow.ai on November 4, 2021 at 12:44 AM GMT

It includes 385 images.
Mold are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 600x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* Randomly crop between 0 and 20 percent of the image
* Random exposure adjustment of between -25 and +25 percent


